
MAKE

make automatically creates a file 'mybigfile.txt' 

SCRIPTS

To run automated scripts testing the performance of these functions 
type the following in the terminal: 

1. To test the write data rate for 10 different block sizes in the range of 100B to 3MB:

python3 write_expr.py

2. To test the read data rate for 10 different block sizes in the range of 100B to 3MB:

python3 read_expr.py