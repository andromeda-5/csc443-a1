/**
 * populate a random array (which is already 
 * allocated with enough memory) to hold bytes bytes.
 */
void random_array(char *array, long bytes);

